from setuptools import setup

setup(
    name="gadfs-shuffle",
    install_requires="gadfs",
    entry_points={"gadfs": ["shuffle = gadfs_shuffle"]},
    py_modules=["gadfs_shuffle"],
)
