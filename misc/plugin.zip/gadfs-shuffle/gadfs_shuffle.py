import logging
import random

import gadfs
from gadfs.hookspecs import Population, Df


@gadfs.hookimpl
def crossover(population: Population, pool: Df):
    logging.info('using shuffle crossover')
    l = list(population.items())
    random.shuffle(l)
    return dict(l)
    

@gadfs.hookimpl
def mutate(population: Population, pool: Df, mutation_rate: float):
    logging.info('using shuffle mutate')
    l = list(population.items())
    random.shuffle(l)
    return dict(l)
