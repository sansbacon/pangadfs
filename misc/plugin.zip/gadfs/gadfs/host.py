import logging

import names
import pandas as pd
import pluggy

from gadfs import hookspecs, lib
from gadfs.ga import GeneticAlgorithm

import click


@click.command()
@click.option('-e', '--excluded_plugins', type=str, default=None, help='Plugins to exclude')
def main(excluded_plugins):
    # so you can exclude installed plugins if you have multiples
    # will always fall back on the default plugin as needed
    logging.basicConfig(level=logging.INFO)
    pm = get_plugin_manager()

    if excluded_plugins:
        for plugin_name in excluded_plugins.split(';'):
            plug = pm.get_plugin(plugin_name)
            if plug:
                logging.info(f'Unregistered plugin {plugin_name}')
                pm.unregister(plug)
            else:
                logging.warning(f'Could not unregister plugin {plugin_name} - does not exist')

    data = {
      'id': range(1, 100),
      'full_name': [names.get_full_name() for _ in range(1, 100)]
    }

    ga = GeneticAlgorithm(hook=pm.hook, pool=pd.DataFrame(data))
    population = ga.populate()
    _ = ga.crossover(population=population)
    _ = ga.mutate(population=population, mutation_rate=0.05)


def get_plugin_manager():
    pm = pluggy.PluginManager("gadfs")
    pm.add_hookspecs(hookspecs)
    pm.load_setuptools_entrypoints("gadfs")
    pm.register(lib)
    return pm


if __name__ == "__main__":
    main()