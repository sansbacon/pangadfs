import logging
import gadfs
from gadfs.hookspecs import Population, Df


@gadfs.hookimpl(trylast=True)
def crossover(population: Population, pool: Df):
    logging.info('using default crossover')
    return population


@gadfs.hookimpl(trylast=True)
def mutate(population: Population, pool: Df, mutation_rate: float):
    logging.info('using default mutate')
    return population
