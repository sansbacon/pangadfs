from typing import Dict, Tuple
import pluggy
from pandas.core.api import DataFrame

hookspec = pluggy.HookspecMarker("gadfs")
Population = Dict[Tuple, Tuple]
Df = DataFrame


@hookspec(firstresult=True)
def crossover(population: Population, pool: Df):
    """Implement crossover.

    Args:
        population (Population): the existing population of teams
        pool (Df): the entire player pool

    Returns:
        Population: new population
    """


@hookspec(firstresult=True)
def mutate(population: Population, pool: Df, mutation_rate: float):
    """Mutates population at given mutation rate.

    Args:
        population (Population): the existing population of teams
        pool (Df): the entire player pool
        mutation_rate (float): between 0 and 1

    Returns:
        Population: new population
    """