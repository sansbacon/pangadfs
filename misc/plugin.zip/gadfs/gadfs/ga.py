import random


class GeneticAlgorithm:

    def __init__(self, hook, pool, initial_size=10, team_size=5):
        self.hook = hook
        self.pool = pool
        self.initial_size = initial_size
        self.team_size = team_size

    def crossover(self, population):
        return self.hook.crossover(population=population, 
                                   pool=self.pool)

    def mutate(self, population, mutation_rate):
        return self.hook.mutate(population=population, 
                                pool=self.pool, 
                                mutation_rate=mutation_rate)

    def populate(self):
        population = {}
        while len(list(population.keys())) < self.initial_size:
            mapping = {
                row.id: row.full_name
                for row in self.pool.sample(self.team_size).sort_values('id').itertuples()
            }
            population[tuple(mapping.keys())] = tuple(mapping.values())
        return population

        
if __name__ == '__main__':
    pass