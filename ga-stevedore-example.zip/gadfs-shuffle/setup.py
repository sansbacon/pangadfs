from setuptools import setup, find_packages


setup(
    name='gadfs-shuffle',
    packages=find_packages(),
    provides=['gadfs_shuffle'],
    include_package_data=True,
    entry_points={
        'gadfs.crossover': ['crossover_shuffle = gadfs_shuffle.gadfs_shuffle:ShuffleCrossover'],
        'gadfs.mutate': ['mutate_shuffle = gadfs_shuffle.gadfs_shuffle:ShuffleMutate'],
    },
    zip_safe=False,
)

