import logging
import random

from gadfs.base import CrossoverBase, MutateBase, Population, Df


class ShuffleCrossover(CrossoverBase):
    """Shuffle crossover technique"""

    def crossover(population: Population, pool: Df):
        logging.info('using shuffle crossover')
        l = list(population.items())
        random.shuffle(l)
        return dict(l)


class ShuffleMutate(MutateBase):
    """Shuffle mutate technique"""

    def mutate(population: Population, pool: Df, mutation_rate: float):
        logging.info('using shuffle mutate')
        l = list(population.items())
        random.shuffle(l)
        return dict(l)
