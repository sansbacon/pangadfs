from setuptools import setup, find_packages

setup(
    name="gadfs",
    entry_points={
        'gadfs.crossover': ['crossover_default = gadfs.default:DefaultCrossover'],
        'gadfs.mutate': ['mutate_default = gadfs.default:DefaultMutate'],
        'gadfs.populate': ['populate_default = gadfs.default:DefaultPopulate'],
        'gadfs.fitness': ['fitness_default = gadfs.default:DefaultFitness'],
        'gadfs.validate': ['validate_default = gadfs.default:DefaultValidate'],
        'console_scripts': ['gaopt=app.app:main']
    },
    packages=find_packages(),
)